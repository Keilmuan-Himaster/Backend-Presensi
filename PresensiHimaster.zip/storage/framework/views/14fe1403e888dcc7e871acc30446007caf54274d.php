<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-banner home-banner">
      <div class="row align-items-center flex-wrap-reverse h-100">
        <div class="col-md-6 py-5 wow fadeInLeft">
        <?php if(Auth::check()): ?>
            <h1 class="mb-4">Selamat Pagi</h1>
            <h1 class="mb-4"><?php echo e($user->name); ?></h1>
            <?php $__currentLoopData = $check_code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $code->code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($code->status == 0): ?>
                            <?php continue; ?>
                        <?php else: ?>
                        <h5 class="my-3">Ada absen <?php echo e($code->title); ?></h5>
                            <form action="<?php echo e(route('input')); ?>" method="post" enctype="multipart/form">
                                    <?php echo csrf_field(); ?>
                                    <div class="form_group">
                                        <input type="text"id="code" name="code" class="form-control" placeholder="CODE....">
                                        <input type="text" id='id' name='id' hidden value="<?php echo e($code->id); ?>">
                                        <input type="text" id="cek" name="cek" hidden value="<?php echo e($code->code); ?>">
                                        <input type="text" id="code_id" name="code_id" hidden value="<?php echo e($code->id); ?>">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                            </form>
                        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <h1 class="mb-4">Selamat Datang</h1>
        <p class="text-lg text-grey mb-5">Silakan login terlebih dahulu</p>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-split">Login <div class="fab"><span class="mai-play"></span></div></a>
        <?php endif; ?>
        
        
    </div>
    <div class="col-md-6 py-5 wow zoomIn">
        <div class="img-fluid text-center">
            <img src="<?php echo e(asset('img/HIMASTER.png')); ?>"  width="400"  alt="">
          </div>
        </div>
      </div>
      <a href="#jadwal" class="btn-scroll" data-role="smoothscroll"><span class="mai-arrow-down"></span></a>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\PresensiHimaster\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>
<!-- Logout Modal-->
<div class="modal fade" id="formInput" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Input <?php echo e(($message)); ?></h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">
            <form method="POST" action="<?php echo e(route('event.input')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="structure_id">Divisi</label>
                  <select class="form-control" id="structure_id" name="structure_id">
                    <option hidden>Select Divisi</option>
                    <?php $__currentLoopData = $structure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $structure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($structure->id); ?>"><?php echo e($structure->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="name">Kegiatan</label>
                  <input type="text" class="form-control" id="name" name="name" placeholder="contoh : Tutorial" aria-describedby="emailHelp">
                  <small id="nameHelp" class="form-text text-muted">Isi sesuai dengan bagian yang ada di Himaster</small>
                </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Logout</button>
        </div>
    </form>
    </div>
</div>
</div>
<?php /**PATH D:\laragon\www\PresensiHimaster\resources\views/backend/master_data/event/__formInput.blade.php ENDPATH**/ ?>
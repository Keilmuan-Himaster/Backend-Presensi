<!-- Logout Modal-->
<div class="modal fade" id="formInput" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <form method="POST" action="<?php echo e(route('member.input.event')); ?>">
    <?php echo csrf_field(); ?>
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Input <?php echo e(($message)); ?></h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">
                <div class="form-group">
                  <label for="event_id">Divisi</label>
                  <select class="form-control" id="event_id" name="event_id">
                    <option hidden>Select Divisi</option>
                    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($event->id); ?>"><?php echo e($event->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input type="text" name="user_id" value="<?php echo e($data->id); ?>" hidden><?php echo e($data->id); ?>

                  </select>
                </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Submit</button>
            <?php echo e($data->name); ?>

        </div>
    </form>
    </div>
</div>
</div>
<?php /**PATH D:\laragon\www\PresensiHimaster\resources\views/backend/master_data/member/__formInput.blade.php ENDPATH**/ ?>